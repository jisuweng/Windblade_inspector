roslaunch wind_generator_gazebo sim_bringup.launch 

rosrun fans_move fans_move.py
