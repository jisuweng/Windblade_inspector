#!/usr/bin/env python
import rospy
import actionlib
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from control_msgs.msg import FollowJointTrajectoryAction, FollowJointTrajectoryGoal

def main():
    rospy.init_node('trajectory_publisher')

    # Create an action client
    client = actionlib.SimpleActionClient('fans_controller/follow_joint_trajectory', FollowJointTrajectoryAction)
    rospy.loginfo("Waiting for joint trajectory action server...")
    client.wait_for_server()
    rospy.loginfo("Connected to joint trajectory action server")

    # Create a new trajectory
    trajectory = JointTrajectory()
    trajectory.joint_names = ['fans_joint']

    # Define several points in the trajectory
    points = [
        JointTrajectoryPoint(positions=[0.0], velocities=[0.0], accelerations=[0], time_from_start=rospy.Duration(0)),
        JointTrajectoryPoint(positions=[10000], velocities=[0.2], accelerations=[1], time_from_start=rospy.Duration(3000)),
        # Add more points as needed
    ]

    trajectory.points = points

    # Create and send the trajectory goal
    goal = FollowJointTrajectoryGoal()
    goal.trajectory = trajectory

    rospy.loginfo("Sending goal to the action server...")
    client.send_goal(goal)

    rospy.loginfo("Waiting for the action server to complete the goal...")
    client.wait_for_result()

    # Print the result
    rospy.loginfo("Action completed. Result: %s" % client.get_result())

if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        pass